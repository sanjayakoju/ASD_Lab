package customers;

public interface ICustomerDAO {
	void save(Customer customer) ;
}
